import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { UtilityHelper } from '../../../core/helpers/utility.helpers';

@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss',
})
export class ProfileComponent {
  profileForm!: FormGroup;
  selectedImage: string | ArrayBuffer | null = null;
  isPasswordVisible = false;
  isPasswordVisible1 = false;
  isPasswordVisible2 = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private utility: UtilityHelper
  ) {}

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      firstName: ['test', Validators.required],
      lastName: ['test', Validators.required],
      email: ['test@yopmail.com', [Validators.required, Validators.email]],
      countryCode: ['965', Validators.required],
      phoneNumber: ['98563214', Validators.required],
      oldPassword: [''],
      newPassword: [''],
      confirmNewPassword: [''],
    });
  }

  // new password
  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  // old password
  togglePasswordVisibility1() {
    this.isPasswordVisible1 = !this.isPasswordVisible1;
  }

  // confirm password
  togglePasswordVisibility2() {
    this.isPasswordVisible2 = !this.isPasswordVisible2;
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/auth/login']);
    this.utility.toastShow('success', 'You have been logged out successfully.');
  }
}
