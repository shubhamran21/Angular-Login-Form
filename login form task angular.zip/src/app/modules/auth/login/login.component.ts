import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { REGEX_PATTERNS } from '../../../core/constants/app-constant';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';
import { UtilityHelper } from '../../../core/helpers/utility.helpers';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  isPasswordVisible = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private utility: UtilityHelper
  ) {
    this.loginForm = this.fb.group({
      email: [
        '',
        [Validators.required, Validators.pattern(REGEX_PATTERNS.email)],
      ],
      phone: '',
      phoneCode: '',
      password: ['', Validators.required],
      deviceToken: '',
      deviceType: '',
      deviceModel: '',
      appVersion: '',
      osVersion: '',
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    this.loginForm.markAllAsTouched();

    if (this.loginForm.invalid) {
      return; // stop execution if form is invalid
    }
    
    this.authService.show();
    this.authService.login(this.loginForm.value).subscribe({
      next: (res: any) => {
        this.authService.hide();
        if (res.status === 1) {
          localStorage.setItem('loginData', JSON.stringify(res.data));
          this.router.navigate(['/profile']);
          this.utility.toastShow('success', res.message);
        } else {
          this.utility.toastShow('error', res.message);
        }
      },
      error: (err) => {
        this.authService.hide();
        const errorMessage =
          err.error?.message || 'Something went wrong. Please try again later.';
        this.utility.toastShow('error', errorMessage);
      },
    });
  }

  //togle password
  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  get email() {
    return this.loginForm.get('email')!;
  }

  get password() {
    return this.loginForm.get('password')!;
  }
}
