import { Routes } from '@angular/router';
import { ProfileComponent } from './modules/my-account/profile/profile.component';

export const routes: Routes = [

    {
        path: '',
        redirectTo: 'auth/login',
        pathMatch: 'full',
    },
    {
        path: 'auth',
        loadChildren: () => import('../app/modules/auth/auth.module').then((m) => m.AuthModule),
    },
    // {
    //     path: 'profile',
    //     loadChildren: () => import('../app/modules/my-account/my-account.module').then((m) => m.MyAccountModule),
    // },
 { path: 'profile', component: ProfileComponent },

];
