 
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})

export class UtilityHelper {
  
 constructor(private toast: ToastrService) {}

 toastShow(type: any, message: any, position: string = 'toast-top-right') {
    let toastDescription = {
      positionClass: position,
      progressBar: true,
      closeButton: false,
      tapToDismiss: false,
      timeOut: 3000,
      extendedTimeOut: 3000,
      disableTimeOut: false,
    };

    switch (type) {
      case 'success':
        this.toast.success(message, undefined, toastDescription);
        break;
      case 'warning':
        this.toast.warning(message, undefined, toastDescription);
        break;
      case 'error':
        this.toast.error(message, undefined, toastDescription);
        break;
      default:
        this.toast.info(message, undefined, toastDescription);
        break;
    }
  }
}
