import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private spinner: NgxSpinnerService, private http: HttpClient) {}

  show() {
    this.spinner.show();
  }

  hide() {
    setTimeout(() => {
      this.spinner.hide();
    }, 500);
  }

  // Login

  login(data: any) {
    const url =
      'https://dev-api.wanasti.com/api/v1/user/login?lang=en&currencyCode=KW';
    return this.http.post(url, data).pipe(map((response: any) => response));
  }
}
